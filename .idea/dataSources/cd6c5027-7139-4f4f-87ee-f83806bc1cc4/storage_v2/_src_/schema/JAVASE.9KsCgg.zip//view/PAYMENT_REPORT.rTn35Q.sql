create view PAYMENT_REPORT as
select P.ID    as payment_id,
       C.ID   as customer_id,
       C.NAME   as customer_name,
       C.FAMILY as customer_family,
       P.TOTALCOST as total_cost,
       P.TYPE as payment_type,
       P.PAYMENTDATE as payment_date
from payment_tbl P,
     customer_tbl C
where P.customer_id = C.ID
/

