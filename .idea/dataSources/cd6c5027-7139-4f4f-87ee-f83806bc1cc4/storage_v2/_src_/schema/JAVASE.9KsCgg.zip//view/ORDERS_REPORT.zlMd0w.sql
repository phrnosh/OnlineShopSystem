create view ORDERS_REPORT as
select O.ID    as order_id,
       C.ID   as customer_id,
       C.NAME   as customer_name,
       C.FAMILY as customer_family,
       D.PRODUCTS_ID as products_id,
       O.AMOUNT as amount,
       O.DISCOUNT as discount,
       O.ORDERDATE
from orders_tbl O,
     customer_tbl C,
     orderDetails_tbl D
where O.customer_id = C.ID and
      D.customer_id = O.customer_id
/

